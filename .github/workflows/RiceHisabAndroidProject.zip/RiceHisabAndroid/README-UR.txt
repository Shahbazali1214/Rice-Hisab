Rice Hisab Android Project

Yeh Android Studio project hai; yeh abhi compiled APK file nahin hai.

APK banane ka tareeqa:
1. Computer par Android Studio install karein.
2. Android Studio mein "Open" par click karke RiceHisabAndroid folder select karein.
3. Gradle sync mukammal hone dein.
4. Menu: Build > Build Bundle(s) / APK(s) > Build APK(s).
5. APK app/build/outputs/apk/debug/app-debug.apk mein milegi.

Hisaab ka tareeqa:
- 137.15 ka matlab 137 Mann aur 15 Kilo.
- 1 Mann = 40 Kilo.
- Cut har poore Mann par lagta hai. Misal: 137 Mann par 1 kilo cut = 137 kilo cut.
- Internet permission istemal nahin hoti.
